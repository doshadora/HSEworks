﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;


namespace Лабораторная_8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private string fio = "";
        private int race = 0;
        private int bus = 0;
        private string sost = "";

        private void button1_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < dataGridView1.RowCount - 1; i++)
            {
                dataGridView1.Rows[i].DefaultCellStyle.BackColor = Color.White;
            }

            if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "" && textBox4.Text != "")
            {
                int j = dataGridView1.Rows.Add();
                AddInfoInTable(textBox2.Text, Convert.ToInt32(textBox1.Text), Convert.ToInt32(textBox3.Text), textBox4.Text, j);

            }

            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            button1.Focus();// add кнопка
        }

        private void AddInfoInTable(string FIO, int raceNumber, int busNumber, string sost, int i)
        {
            dataGridView1.Rows[i].SetValues(raceNumber, FIO, busNumber, sost);
        }
        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            dataGridView1.Rows[dataGridView1.RowCount - 1].Selected = false;
            for (int k = 0; k < 4; k++)
                dataGridView1.Rows[dataGridView1.RowCount - 1].Cells[k].Selected = false;
            int i = e.RowIndex;
            if (i >= 0)
            {
                if (i != dataGridView1.RowCount - 1)
                {
                    textBox1.Text = dataGridView1.Rows[i].Cells[0].Value.ToString();
                    textBox2.Text = dataGridView1.Rows[i].Cells[1].Value.ToString();
                    textBox3.Text = dataGridView1.Rows[i].Cells[2].Value.ToString();
                    textBox4.Text = dataGridView1.Rows[i].Cells[3].Value.ToString();
                    dataGridView1.AllowUserToDeleteRows = true;
                    foreach (DataGridViewCell oneCell in dataGridView1.SelectedCells)
                    {
                        if (oneCell.Selected)
                            dataGridView1.Rows.RemoveAt(oneCell.RowIndex);
                    }
                }
            }
            dataGridView1.Rows[dataGridView1.RowCount - 1].Cells[0].Selected = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView1.RowCount > 1 && dataGridView1.RowCount > dataGridView1.SelectedRows.Count && dataGridView1.SelectedCells.ToString() != "")
                    if (dataGridView1.SelectedRows.ToString() != "")
                        foreach (DataGridViewCell oneCell in dataGridView1.SelectedCells)
                        {
                            if (oneCell.Selected)
                                dataGridView1.Rows.RemoveAt(oneCell.RowIndex);
                        }
            }
            catch (InvalidOperationException)
            { }
        }
        private void button3_MouseDown(object sender, MouseEventArgs e)
        {

            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox5.Text != "")
            {
                int CountResults = 0;
                for (int i = 0; i < dataGridView1.RowCount - 1; i++)
                    dataGridView1.Rows[i].DefaultCellStyle.BackColor = Color.White;

                for (int i = 0; i < dataGridView1.RowCount - 1; i++)
                    if (dataGridView1.Rows[i].Cells[1].Value.ToString().IndexOf(textBox5.Text) != -1)
                    {
                        CountResults++;
                        dataGridView1.Rows[i].DefaultCellStyle.BackColor = Color.LightGreen;
                    }
                if (CountResults == 0)
                {
                    MessageBox.Show("Водитель не найден!");
                    textBox5.Clear();
                    textBox5.Focus();
                }
                textBox5.Clear();
            }
        }
        private bool FIO_Check(string FIO)
        {
            Regex rg = new Regex(@"^[А-Я][а-я]{1,} [А-Я]{1}[.]{1}[А-Я]{1}[.]{1}$");
            Match m = rg.Match(FIO);
            return m.Success;
        }
        private bool Race_Check(string race)
        {
            Regex rg = new Regex(@"^[0-9]{1,10}$");
            Match m = rg.Match(race);
            if (m.Success)
                if (Convert.ToInt32(race) > 0) return true;
                else return false;
            else return false;
        }
        private bool Bus_Check(string bus)
        {
            Regex rg = new Regex(@"^[0-9]{1,}$");
            Match m = rg.Match(bus);
            if (m.Success)
                if (Convert.ToInt32(bus) > 0) return true;
                else return false;
            else return false;
        }
        private bool Sost_Check(string sost)
        {
            Regex rg = new Regex(@"^[+,-]{1}$");
            Match m = rg.Match(sost);
            return m.Success;
        }
        private void button4_Click(object sender, EventArgs e)
        {
            if (dataGridView1.RowCount > 1)
            {
                int CountParked = 0;
                for (int i = 0; i < dataGridView1.RowCount - 1; i++)
                    dataGridView1.Rows[i].DefaultCellStyle.BackColor = Color.White;

                for (int i = 0; i < dataGridView1.RowCount - 1; i++)
                    if (dataGridView1.Rows[i].Cells[3].Value.ToString().IndexOf("+") != -1)
                    {
                        CountParked++;
                        dataGridView1.Rows[i].DefaultCellStyle.BackColor = Color.MediumAquamarine;
                    }
                if (CountParked == 0)
                {
                    MessageBox.Show("Автобусов в парке нет!");
                    textBox5.Clear();
                    textBox5.Focus();
                }
            }
        }
        private void dataGridView1_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            dataGridView1.Rows[dataGridView1.RowCount - 1].Selected = false;
            for (int i = 0; i < 4; i++)
                dataGridView1.Rows[dataGridView1.RowCount - 1].Cells[i].Selected = false;
        }
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            dataGridView1.Rows[dataGridView1.RowCount - 1].Selected = false;
            for (int i = 0; i < 4; i++)
                dataGridView1.Rows[dataGridView1.RowCount - 1].Cells[i].Selected = false;
        }

        private void сохранитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dataGridView1.RowCount > 1)
            {
                System.IO.Stream myStream;

                SaveFileDialog saveTags = new SaveFileDialog();
                saveTags.Filter = "All file (*.*) | *.*| Text file |*.txt";
                saveTags.FilterIndex = 2;

                if (saveTags.ShowDialog() == DialogResult.OK)
                {
                    if ((myStream = saveTags.OpenFile()) != null)
                    {
                        StreamWriter myWriter = new StreamWriter(myStream);
                        try
                        {
                            for (int i = 0; i < dataGridView1.RowCount - 1; i++)
                            {
                                for (int j = 0; j < dataGridView1.ColumnCount; j++)
                                {
                                    myWriter.Write(dataGridView1.Rows[i].Cells[j].Value.ToString());
                                    if ((dataGridView1.ColumnCount - j) != 1) myWriter.Write(":");
                                }

                                if (((dataGridView1.RowCount - 1) - i - 1) != 0) myWriter.WriteLine();
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                        finally
                        {
                            myWriter.Close();
                        }
                    }
                    myStream.Close();
                }
            }
        }

        private void открытьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
            System.IO.Stream myStr = null;
            OpenFileDialog OpenTags = new OpenFileDialog();
            OpenTags.Filter = "All file (*.*) | *.*| Text file |*.txt";
            OpenTags.FilterIndex = 2;
            if (OpenTags.ShowDialog() == DialogResult.OK)
            {
                if ((myStr = OpenTags.OpenFile()) != null)
                {
                    StreamReader myRead = new StreamReader(myStr);
                    string[] str;
                    int num = 0;
                    string[] str1 = myRead.ReadToEnd().Split('\n');
                    num = str1.Count();
                    dataGridView1.RowCount = num + 1;
                    for (int i = 0; i < num; i++)
                    {
                        {

                            str = str1[i].Split(':');
                            for (int j = 0; j < dataGridView1.ColumnCount; j++)
                            {
                                try
                                {
                                    dataGridView1.Rows[i].Cells[j].Value = str[j];
                                }
                                catch (Exception ex)
                                {
                                    MessageBox.Show(ex.Message);
                                }
                            }
                        }
                    }
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (dataGridView1.RowCount > 1)
            {
                int CountParked = 0;
                for (int i = 0; i < dataGridView1.RowCount - 1; i++)
                    dataGridView1.Rows[i].DefaultCellStyle.BackColor = Color.White;

                for (int i = 0; i < dataGridView1.RowCount - 1; i++)
                    if (dataGridView1.Rows[i].Cells[3].Value.ToString().IndexOf("-") != -1)
                    {
                        CountParked++;
                        dataGridView1.Rows[i].DefaultCellStyle.BackColor = Color.Aquamarine;
                    }
                if (CountParked == 0)
                {
                    MessageBox.Show("Автобусов на маршрутах нет!");
                    textBox5.Clear();
                    textBox5.Focus();
                }
                else
                {
                    MessageBox.Show("Автобусов на маршрутах: " + CountParked);
                    textBox5.Clear();
                    textBox5.Focus();
                }
            }
        }

        private void textBox1_Validating_1(object sender, CancelEventArgs e)
        {
            if (Race_Check(textBox1.Text) == true) race = Convert.ToInt32(textBox1.Text);
            else
            {
                MessageBox.Show("Ошибка!");
                textBox1.Clear();
                textBox1.Focus();
            }
        }

        private void textBox2_Validating_1(object sender, CancelEventArgs e)
        {
            if (FIO_Check(textBox2.Text) == true) fio = textBox2.Text;
            else
            {
                MessageBox.Show("Ошибка!");
                textBox2.Clear();
                textBox2.Focus();
            }
        }

        private void textBox3_Validating_1(object sender, CancelEventArgs e)
        {
            if (Bus_Check(textBox3.Text) == true) bus = Convert.ToInt32(textBox3.Text);
            else
            {
                MessageBox.Show("Ошибка!");
                textBox3.Clear();
                textBox3.Focus();
            }
        }

        private void textBox4_Validating_1(object sender, CancelEventArgs e)
        {
            if (Sost_Check(textBox4.Text) == true) sost = textBox4.Text;
            else
            {
                MessageBox.Show("Ошибка!");
                textBox4.Clear();
                textBox4.Focus();
            }
        }

        private void textBox1_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar) || Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox2_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (Char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back || e.KeyChar == ' ' || e.KeyChar == '.')
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox3_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar) || Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox4_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '+' || e.KeyChar == '-')
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }
    }
}