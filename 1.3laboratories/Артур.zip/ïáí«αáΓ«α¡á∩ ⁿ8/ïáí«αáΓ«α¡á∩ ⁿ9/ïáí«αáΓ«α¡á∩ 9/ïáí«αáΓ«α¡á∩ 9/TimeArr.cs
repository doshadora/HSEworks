﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Лабораторная_9
{
    class TimeArr
    {
        private Time[] array;
        private int size;
        static int count = 0;

        public Time[] Array
        {
            get { return array; }
            set { array = value; }
        }

        public TimeArr()
        {
            array = null;
            size = 0;
        }

        public TimeArr(int s, int p)
        {
            Time[] massiv = new Time[s];
            bool ok;
            string buf;
            for (int i = 0; i < s; i++)
            {
                Console.WriteLine("{0} элемент", i + 1);
                Time t = new Time();
                Console.Write("Введите часы: ");
                do
                {
                    buf = Console.ReadLine();
                    ok = int.TryParse(buf, out t.hours);
                    if (!ok || t.hours < 0 || t.hours > 23) Console.WriteLine("Ошибка ввода - повторите снова");
                }
                while (!ok || t.hours < 0 || t.hours > 23);
                Console.Write("Введите минуты: ");
                do
                {
                    buf = Console.ReadLine();
                    ok = int.TryParse(buf, out t.minutes);
                    if (!ok || t.minutes < 0) Console.WriteLine("Ошибка ввода - повторите снова");
                }
                while (!ok || t.minutes < 0);
                if (t.minutes >= 60)
                {
                    int min2 = t.minutes % 60;
                    int hour2 = (t.minutes - min2) / 60;
                    t.hours = t.hours + hour2;
                    t.minutes = min2;
                }
                if (t.hours >= 24)
                {
                    int hours2 = t.hours - 24;
                    t.hours = hours2;
                }
                massiv[i] = t;
                count++;
            }
            array = massiv;
            size = s;
            for (int i = 0; i < s; i++)
            {
                Console.WriteLine("{0} элемент", i + 1);
                array[i].Show();
            }
        }
        private static Random rnd = new Random();

        public TimeArr(int size2)
        {
            Time[] massiv = new Time[size2];
            for (int i = 0; i < size2; i++)
            {
                Console.WriteLine("{0} элемент", i + 1);
                Time t = new Time();
                t.hours = rnd.Next(0, 23);
                t.minutes = rnd.Next(0, 59);
                t.Show();
                massiv[i] = t;
                count++;
            }
            array = massiv;
            size = size2;
        }

        public void index(TimeArr mas, int number)
        {
            int l = mas.Array.Length;
            if ((number > l) || (number <= 0))
                Console.WriteLine("Индекс выходит за границы диапазона.");
            else
                mas.Array[number - 1].Show();
        }

        public void show()
        {
            for (int i = 0; i < size; i++)
            {
                Console.Write("{0} элемент - ", i + 1);
                array[i].Show();
            }
        }

        public int GetCount()
        {
            return count;
        }

        public void MaxTime()
        {
            int max_index = 0;
            int[] mass = new int[size];
            for (int i = 0; i < size; i++)
                mass[i] = (int)array[i];
                int max = mass.Max();
            for (int i = 0; i < size; i++)
                if (max == mass[i]) max_index = i+1;    
            Console.WriteLine("Номер наибольшего элемента - " + max_index);
        }

    }
}
