﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Лабораторная_9
{
    class Time
    {
        public int hours;
        public int minutes;
        public int count;

        public Time()
        {
            hours = 0;
            minutes = 0;
            count++;
        }

        public Time(int h, int m)
        {
            hours = h;
            minutes = m;
            count++;
        }

        public int Hours
        {
            get { return hours; }
            set { if ((value >= 0) && (value <= 23)) hours = value; }
        }

        public int Minutes
        {
            get { return minutes; }
            set { if ((value >= 0) && (value <= 59)) minutes = value; }
        }

        public void Show()
        {
            if (minutes >= 60)
            {
                int min2 = minutes % 60;
                int hour2 = (minutes - min2) / 60;
                hours = hours + hour2;
                minutes = min2;
            }
            if (hours >= 24)
            {
                int hours2 = hours - 24;
                hours = hours2;
            }
            if ((hours < 10) && (minutes < 10))
                Console.WriteLine("0" + hours + ":" + "0" + minutes);
            else
            {
                if (minutes < 10)
                    Console.WriteLine(hours + ":" + "0" + minutes);
                else
                {
                    if (hours < 10)
                        Console.WriteLine("0" + hours + ":" + minutes);
                    else Console.WriteLine(hours + ":" + minutes);
                }
            }
        }

        public int GetCount()
        {
            return count;
        }

        public static Time operator++(Time t1)
        {
            int time = t1.hours * 60 + t1.minutes;
            time++;
            if(time>=1440)
            {
                t1.hours = 0;
                t1.minutes = 0;
            }
            else
            {
                t1.hours = time / 60;
                t1.minutes = time % 60;
            }
            return t1;
        }

        public static Time operator--(Time t1)
        {
            int time = t1.hours * 60 + t1.minutes;

            time--;

            if (time <= 0)
            {
                t1.hours = 0;
                t1.minutes = 0;
            }
            else
            {
                t1.hours = time / 60;
                t1.minutes = time % 60;
            }
            return t1;
        }

        public static explicit operator int(Time t1)
        {
            int time = t1.hours ;
            return time;
        }

        public static implicit operator bool(Time t1)
        {
            if ((t1.minutes == 0)&(t1.hours==0))
                return false;
            else
                return true;
        }

        public void minus(Time t1, int Minutes)
        {

            Time temp = new Time();
            int time = (t1.hours * 60 + t1.minutes) - Minutes;

            if (time <= 0)
            {
                temp.hours = 0;
                temp.minutes = 0;
            }
            else
            {
                temp.hours = time / 60;
                temp.minutes = time % 60;
            }

            Console.Write("Результат: ");
            temp.Show();
        }

        public static Time operator + (int Minutes, Time t1)
        {
            int summ = (t1.hours * 60 + t1.minutes) + Minutes;
            t1.minutes = summ % 60;
            t1.hours = (summ - t1.minutes) / 60;
            return t1;
        }

        public static Time operator + (Time t1, int Minutes)
        {
            int summ = Minutes + (t1.hours * 60 + t1.minutes);
            t1.minutes = summ % 60;
            t1.hours = (summ - t1.minutes) / 60;
            return t1;
        }

        public static Time operator +(Time t1, Time t2)
        {
            int h = t1.hours + t2.hours;
            int m = t1.minutes + t2.minutes;
            t1.hours = h;
            t1.minutes = m;
            return t1;
        }

    }
}
