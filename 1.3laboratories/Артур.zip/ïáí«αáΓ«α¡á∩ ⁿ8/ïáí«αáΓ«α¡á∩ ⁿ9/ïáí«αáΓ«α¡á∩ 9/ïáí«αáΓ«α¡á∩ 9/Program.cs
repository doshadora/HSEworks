﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Лабораторная_9
{
    class Program
    {
        static void Main(string[] args)
        {
            bool Exit = false;

            do
            {
                Console.WriteLine("Выберите задачу.");
                Console.WriteLine();
                Console.WriteLine("1. Часть 1 (- время)");
                Console.WriteLine("2. Часть 2 (Перегруженные операции)");
                Console.WriteLine("3. Часть 3 (Массив)");
                Console.WriteLine("4. Выход");
                Console.WriteLine();
                Console.Write("Введите номер задачи: ");
                Console.WriteLine();

                int choosePart = Choose();
                switch (choosePart)
                {
                    case 1:
                        {
                            part1();
                            break;
                        }

                    case 2:
                        {
                            part2();
                            break;
                        }

                    case 3:
                        {
                            part3();
                            break;
                        }

                    case 4:
                        {
                            Exit = true;
                            break;
                        }
                    default:
                        {
                            Console.WriteLine("Ошибка ввода! Попробуйте еще раз!");
                            break;
                        }
                }
            } while (!Exit);
        }

        static int Choose()
        {
            int z;
            bool ok;
            string buf;
            do
            {
                buf = Console.ReadLine();
                ok = int.TryParse(buf, out z);
                if (!ok || z < 0 || z > int.MaxValue)
                    Console.WriteLine("Ошибка ввода! Повторите снова!");
                if (z == 0)
                    Console.WriteLine(@"Ошибка ввода! повторите снова!
Количество элементов в массиве должно быть больше 0!");
            }
            while (!ok || z <= 0 || z > int.MaxValue);
            return z;
        }

        public static Time inputKeyboard()
        {
            bool ok;
            string buf;
            int min, hour;
            Console.Write("Введите часы: ");
            do
            {
                buf = Console.ReadLine();
                ok = int.TryParse(buf, out hour);
                if (!ok || hour < 0 || hour > 23) Console.WriteLine("Ошибка ввода - повторите снова");
            }
            while (!ok || hour < 0 || hour > 23);
            Console.Write("Введите минуты: ");
            do
            {
                buf = Console.ReadLine();
                ok = int.TryParse(buf, out min);
                if (!ok || min < 0) Console.WriteLine("Ошибка ввода - повторите снова");
            }
            while (!ok || min < 0);
            if (min >= 60)
            {
                int min2 = min % 60;
                int hour2 = (min - min2) / 60;
                hour = hour + hour2;
                min = min2;
            }
            if (hour >= 24)
            {
                int hours2 = hour - 24;
                hour = hours2;
            }
            Time t = new Time(hour, min);
            return t;
        }

        public static Time inputRandom()
        {
            int min, hour;

            Random rnd = new Random();

            hour = rnd.Next(0, 23);
            min = rnd.Next(0, 59);

            Time t = new Time(hour, min);

            return t;
        }

        public static int Check(out int Answer)
        {
            bool ok;
            string buf;
            do
            {
                buf = Console.ReadLine();
                ok = int.TryParse(buf, out Answer);
                if (!ok) Console.WriteLine("Ошибка! Повторите ввод снова");
            }
            while (!ok);
            return Answer;
        }

        public static Time input()
        {
            Time time = new Time();

            bool exit = false;

            Console.WriteLine("1. Ввод с клавиатуры");
            Console.WriteLine("2. С помощью ДСЧ");
            Console.WriteLine();

            Console.Write("Введите номер: ");
            Console.WriteLine();

            do
            {
                int chooseInp = Choose();
                switch (chooseInp)
                {
                    case 1:
                        {
                            time = inputKeyboard();
                            Console.Write("Время: ");
                            time.Show();
                            Console.WriteLine();
                            exit = true;
                            break;
                        }
                    case 2:
                        {
                            time = inputRandom();
                            Console.Write("Время: ");
                            time.Show();
                            Console.WriteLine();
                            exit = true;
                            break;
                        }
                    default:
                        {
                            Console.WriteLine("Ошибка ввода! Попробуйте снова.");
                            break;
                        }
                }
            } while (!exit);
            return time;
        }

        public static int dobav(Time t1, int Minutes)
        {
            int summ = (t1.hours * 60 + t1.minutes) + Minutes;
            return summ;
        }

        public static int minus(Time t1, int Minutes)
        {
            int razn = (t1.hours * 60 + t1.minutes) - Minutes;
            return razn;
        }

        public static Time plus(Time t1, Time t2)
        {
            Time res = new Time();
            res = t1 + t2;
            return res;
        }

        static void part1()
        {
            Time t1 = new Time();
            Console.WriteLine("Укажите время, с которым будете работать!");
            Console.WriteLine("Выберите способ формирования времени");
            Console.WriteLine();
            t1 = input();
            bool exit = false;
            do
            {
                //Меню
                Console.WriteLine("Выберите операцию.");
                Console.WriteLine();
                Console.WriteLine("1. Вычитание минут типа int (статическая операция)");
                Console.WriteLine("2. Вычитание минут типа int (метод класса)");
                Console.WriteLine("3. Посчитать количество объектов класса.");
                Console.WriteLine("4. Назад");
                int chooseOp = Choose();
                switch (chooseOp)
                {
                    //Вычитание минут(статическая операция)
                    case 1:
                        {
                            int Answer = 0;
                            int Minutes = 0;
                            Console.WriteLine("Сколько минут необходимо вычесть?");
                            Console.WriteLine();
                            Minutes = Check(out Answer);
                            int result = minus(t1, Minutes);
                            Time res = new Time();
                            if (result <= 0)
                            {
                                res.hours = 0;
                                res.minutes = 0;
                            }
                            else
                            {
                                res.hours = result / 60;
                                res.minutes = result % 60;
                            }

                            Console.Write("Результат: ");
                            res.Show();
                            break;
                        }
                    //Вычитание минут(метод класса)
                    case 2:
                        {
                            int Answer = 0;
                            int Minutes = 0;

                            Console.WriteLine("Сколько минут необходимо вычесть?");
                            Console.WriteLine();
                            Minutes = Check(out Answer);
                            Time result = new Time();
                            result.minus(t1, Minutes);
                            Console.WriteLine();
                            break;
                        }
                    //Посчитать количество объектов класса
                    case 3:
                        {
                            Console.WriteLine("В программе создано {0} объектов", t1.GetCount());
                            break;
                        }
                    //Выход и ошибка
                    case 4:
                        {
                            exit = true;
                            break;
                        }
                    default:
                        {
                            Console.WriteLine("Ошибка ввода! Попробуйте еще раз!");
                            break;
                        }
                }
            } while (!exit);
        }

        static void part2()
        {
            Time t1 = new Time();
            Console.WriteLine("Укажите время, с которым будете работать!");
            Console.WriteLine("Выберите способ формирования времени");
            Console.WriteLine();
            t1 = input();
            bool exit = false;
            do
            {
                Console.WriteLine("Выберите операцию.");
                Console.WriteLine();
                Console.WriteLine("1. -- (вычитание минуты) - унарная операция");
                Console.WriteLine("2. int (количество часов) - явная операция приведения типа");
                Console.WriteLine("3. bool (не равны ли часы и минуты нулю?) - неявная операция приведения типа");
                Console.WriteLine("4. +  Time t, целое число (минуты) - бинарная операция");
                Console.WriteLine("5. Time t1, Time t2 - сложение временных интервалов - бинарная операция");
                Console.WriteLine("6. Демонстрационная программа");
                Console.WriteLine("7. Назад");
                int chooseOp = Choose();
                switch (chooseOp)
                {
                    // -- (вычитание минуты)
                    case 1:
                        {
                            if ((t1.minutes == 0) && (t1.hours == 0))
                                Console.WriteLine("Ошибка!");
                            else
                            {
                                Console.Write("Введенное время - ");
                                t1.Show();
                                t1--;
                                Console.Write("Новое время - ");
                                t1.Show();
                            }
                            break;
                        }
                    // int (количество часов) - явная операция приведения типа
                    case 2:
                        {
                            int time = (int)t1;
                            Console.WriteLine("Произведено явное преобразование : " + time + "часов");
                            break;
                        }
                    // bool (не равны ли часы и минуты нулю?) - неявная операция приведения типа
                    case 3:
                        {
                            bool check = t1;
                            Console.WriteLine("Произведено неявное преобразование (результатом является true, если часы и минуты не равны нулю и false в противном случае) : " + check);
                            break;
                        }
                    // +  Time t, целое число (минуты)
                    case 4:
                        {
                            int Answer = 0;
                            int Minutes = 0;
                            Console.WriteLine("Сколько минут необходимо добавить?");
                            Console.WriteLine();
                            Minutes = Check(out Answer);
                            t1 = t1 + Minutes;
                            int summ = t1.hours * 60 + t1.minutes;
                            Console.Write("Результат: " + summ + " минут");
                            Console.WriteLine();
                            break;
                        }
                    //+Time t1, Time t2 – сложение временных интервалов.
                    case 5:
                        {
                            Time t2 = new Time();
                            Time res = new Time();
                            Console.WriteLine("Укажите время, которое будете добавлять!");
                            Console.WriteLine("Выберите способ формирования времени");
                            Console.WriteLine();
                            t2 = input();
                            res = t1 + t2;
                            if (res.minutes >= 60)
                            {
                                int min = res.minutes % 60;
                                int hour = (res.minutes - min) / 60;
                                res.minutes = min;
                                res.hours = res.hours + hour;
                            }
                            if (res.hours >= 24)
                            {
                                int hours = res.hours - 24;
                                res.hours = hours;
                            }
                            Console.Write("Результат: ");
                            res.Show();
                            break;
                        }
                    //Демонстрационная программа
                    case 6:
                        {
                            Time t2 = new Time(2, 54);
                            t2.Show();

                            Time t3 = new Time(0, 78);
                            t3.Show();

                            Time t4 = new Time(14, 0);
                            t4.Show();

                            Time t5 = new Time(25, 12);
                            t5.Show();

                            Time t6 = new Time(20, 102);
                            t6.Show();

                            Time t7 = new Time(10, 6);
                            t7.Show();

                            Time t8 = new Time();
                            Console.WriteLine("1. -- (вычитание минуты) - унарная операция");
                            t8 = t2--;
                            t7.Show();

                            Time t9 = new Time();
                            Console.WriteLine("4. +  Time t, целое число (минуты) - бинарная операция");
                            t9 = t5 + 28;
                            t9.Show();

                            Time t10 = new Time();
                            Console.WriteLine("5. Time t1, Time t2 - сложение временных интервалов - бинарная операция");
                            t10 = t6 + t7;
                            t10.Show();
                            break;
                        }
                    case 7:
                        {
                            exit = true;
                            break;
                        }
                    default:
                        {
                            Console.WriteLine("Ошибка ввода! Попробуйте еще раз!");
                            break;
                        }
                }
            } while (!exit);
        }

        static void part3()
        {
            bool Create = false;
            TimeArr timeAr = new TimeArr();
            bool exit = false;
            do
            {
                Console.WriteLine("Выберите операцию.");
                Console.WriteLine();
                Console.WriteLine("1. Создать массив с клавиатуры");
                Console.WriteLine("2. Созадть массив с помощью ДСЧ");
                Console.WriteLine("3. Вывести указанный элемент");
                Console.WriteLine("4. Вывести массив времен");
                Console.WriteLine("5. Вывести номер наибольшего элемента");
                Console.WriteLine("6. Вывести количество созданных объектов класса");
                Console.WriteLine("7. Назад");
                int chooseOp = Choose();
                switch (chooseOp)
                {
                    //Создать массив с клавиатуры
                    case 1:
                        {
                            Console.Write("Укажите количество элементов в массиве: ");
                            int size = Choose();
                            timeAr = new TimeArr(size, chooseOp);
                            Create = true;
                            break;
                        }
                    //Созадть массив с помощью ДСЧ
                    case 2:
                        {
                            Console.Write("Укажите количество элементов в массиве: ");
                            int size = Choose();
                            timeAr = new TimeArr(size);
                            Create = true;
                            break;
                        }
                    //Вывести указанный элемент
                    case 3:
                        {
                            if (Create)
                            {
                                Console.Write("Укажите номер элемента в массиве: ");
                                int ind = Choose();
                                timeAr.index(timeAr, ind);
                            }
                            else Console.WriteLine("Массив не создан. Создайте массив с помощью п.1 или п.2.");
                            break;
                        }
                    //Вывести массив времен
                    case 4:
                        {
                            if (Create)
                            {
                                timeAr.show();
                            }
                            else Console.WriteLine("Массив не создан. Создайте массив с помощью п.1 или п.2.");
                            break;
                        }
                    //Вывести номер наибольшего элемента
                    case 5:
                        {
                            if (Create)
                            {
                                timeAr.MaxTime();
                            }
                            else Console.WriteLine("Массив не создан. Создайте массив с помощью п.1 или п.2.");
                            break;
                        }
                    //Вывести количество созданных объектов класса
                    case 6:
                        {
                            if (Create)
                            {
                                Console.WriteLine("В программе создано {0} объектов", timeAr.GetCount());
                            }
                            else Console.WriteLine("Массив не создан. Создайте массив с помощью п.1 или п.2.");

                            break;
                        }
                    case 7:
                        {
                            exit = true;
                            break;
                        }
                    default:
                        {
                            Console.WriteLine("Ошибка ввода! Попробуйте еще раз!");
                            break;
                        }
                }
            } while (!exit);
        }
    }
}